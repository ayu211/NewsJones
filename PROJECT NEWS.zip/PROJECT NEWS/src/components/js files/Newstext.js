import React from 'react'
import './../css files/Newstext.css'

function Newstext(props) {
    let{imageUrl, description, title, url} = props;
  return (
    <div className='container'>
      <div class="card">
        <img src={imageUrl} alt="News.." style={{width:"100%"}}/>
        <h1>{title}</h1>
        <p>{description}...</p>
        <a href={url} rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">Read more...</a>
      </div>
    </div>
  )
}

export default Newstext
