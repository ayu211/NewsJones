import React from 'react'
import loading from './spinner.gif'
import './../css files/Spinner.css'

function Spinner() {
  return (
    <div className='loader'>
      <img src={loading} alt="loader img" />
    </div>
  )
}

export default Spinner;
