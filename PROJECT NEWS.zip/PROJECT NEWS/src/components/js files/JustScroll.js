import React, {useEffect, useState} from 'react'
import InfiniteScroll from 'react-infinite-scroll-component';
import './../css files/justscroll.css';
import Newstext from './Newstext';
import Spinner from './Spinner';

function JustScroll() {
    const[articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalResults, setTotalResults] = useState(0);

    const update = async()=>{
    const url = `https://newsapi.org/v2/everything?domains=ndtv.com&apiKey=828064b21f6d4218aac60148f0e45f52`;
        setLoading(true);
        let data = await fetch(url);
        let parsedData = await data.json();
        setArticles(parsedData.articles);
        setTotalResults(parsedData.totalResults);
        setLoading(false);

    }
    useEffect(()=>{
        update();
    },[]);

    const fetchMore= async()=>{
        setPage(page+1);
        const url = `https://newsapi.org/v2/everything?domains=ndtv.com&apiKey=828064b21f6d4218aac60148f0e45f52`;
        let data = await fetch(url);
        let parsedData = await data.json();
        setArticles(articles.concat(parsedData.articles));
        setTotalResults(parsedData.totalResults);
    }

  return (
    <>
        <div className='container'>
            <h2>Just Scroll and Enjoy!!</h2>
            {loading && <Spinner/>}
            <InfiniteScroll
                dataLength={articles.length}
                next={fetchMore}
                hasMore={articles.length !== totalResults}
                loader={<Spinner/>}
                >

                <div className="row">
                    { !loading && articles.map((element) =>{
                        return <div className="col-4">
                                    <Newstext title = {element.title?element.title:""} imageUrl = {element.urlToImage?element.urlToImage:"http://thelongfortgroup.com/public/img/default/no-image-icon.jpg"} description={element.description?element.description:""} url={element.url} />
                                </div>
                    })}</div>
                    </InfiniteScroll>

        </div>
    </>
  )
                }
  

export default JustScroll;
