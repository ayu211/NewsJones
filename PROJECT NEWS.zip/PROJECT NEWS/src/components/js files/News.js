import React, {useState, useEffect} from 'react'
import Newstext from './Newstext';
import './../css files/News.css'
import PropTypes from 'prop-types'
import InfiniteScroll from 'react-infinite-scroll-component';
import Spinner from './Spinner';


function News(props) {
    // https://newsapi.org/v2/top-headlines?country=in&apiKey=828064b21f6d4218aac60148f0e45f52
    const[articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalResults, setTotalResults] = useState(0);

    const update = async()=>{
    const url = `https://newsapi.org/v2/top-headlines?country=${props.country}&category=${props.category}&apiKey=f438cdf3732e49c085067a7e13c966bd&page=${page}&pageSize=${props.pageSize}`;
        setLoading(true);
        let data = await fetch(url);
        let parsedData = await data.json();
        setArticles(parsedData.articles);
        setTotalResults(parsedData.totalResults);
        setLoading(false);

    }
    useEffect(()=>{
        update();
    },[]);

    const fetchMore= async()=>{
        setPage(page+1);
        const url = `https://newsapi.org/v2/top-headlines?country=${props.country}&category=${props.category}&apiKey=f438cdf3732e49c085067a7e13c966bd&page=${page}&pageSize=${props.pageSize}`;
        let data = await fetch(url);
        let parsedData = await data.json();
        setArticles(articles.concat(parsedData.articles));
        setTotalResults(parsedData.totalResults);
    }
  return (
    <>
        <div className='container'>
            <h2>NEWS - Top Headlines</h2>
            {/* <div className="column"> */}
            {loading && <Spinner/>}
            <InfiniteScroll
                dataLength={articles.length}
                next={fetchMore}
                hasMore={articles.length !== totalResults}
                loader={<Spinner/>}
                >

                <div className="row">
                    { !loading && articles.map((element) =>{
                        return <div className="col-4">
                                    <Newstext title = {element.title?element.title:""} imageUrl = {element.urlToImage?element.urlToImage:"http://thelongfortgroup.com/public/img/default/no-image-icon.jpg"} description={element.description?element.description:""} url={element.url} />
                                </div>
                    })}</div>
            </InfiniteScroll>
                    {/* </div> */}
        </div>
    </>
  )
}
News.defaultProps = {
    country: 'in',
    pageSize: 8,
    category: "general",
}
News.propTypes = {
    country: PropTypes.string,
    pageSize: PropTypes.number,
    category: PropTypes.string,
}

export default News
