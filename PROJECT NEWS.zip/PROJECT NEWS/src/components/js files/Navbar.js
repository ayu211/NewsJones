import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import logo from './../../Frame.png';

import './../css files/Navbar.css';

function Navbar({placeholder, data}) {
  const[filterData, setFilterData] = useState([]);
  const[wordEntered, setWordEntered] = useState("");

    const handleFilter=(event)=>{
      const searchWord = event.target.value;
      setWordEntered(searchWord);
      const newFilter = data.filter((value)=>{
        return value.title.toLowerCase().includes(searchWord.toLowerCase());
      });
      if(searchWord === ""){
        setFilterData([]);
      }else{
        setFilterData(newFilter);
      }
    }

  return (
      <nav>
      <div class="topnav">
        <img src={logo} alt="newsjones.." />
        <Link to="/justscroll" style={{fontWeight:'bolder'}}>Just Scroll</Link>
        <div className="dropdown">
          <button class="dropbtn">Categories</button>
            <div class="dropdown-content">
              <Link to="/sports">Sports</Link>
              <Link to="/science">Science</Link>
              <Link to="/business">Business</Link>
              <Link to="/technology">Technology</Link>
              <Link to="/health">Health</Link>
              <Link to="/entertainment">Entertainment</Link>
            </div>
          </div>
        <div class="search-container">
          <form action="/action_page.php">
            <input type="text" placeholder={placeholder} value={wordEntered} onChange={handleFilter}  name="search"/>
            <button type="submit"><i class="fa fa-search"></i></button>
          </form>
      {filterData.length !== 0 && (
        <div className="results">
          {filterData.slice(0,15).map((value,key)=>{
            return (
              <Link className='dataItems' to={value.url}>
                <p>{value.title.slice(0,50)}...</p>
              </Link>
            )
          })}
        </div>
      )}
        </div>
      </div>
      </nav>
      
  )
}

export default Navbar
