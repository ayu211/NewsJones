import './App.css';
import Navbar from './components/js files/Navbar';
import News from './components/js files/News';
import searchData from './data.json';
import {
  BrowserRouter,
  Routes,
  Route
}from "react-router-dom";
import JustScroll from './components/js files/JustScroll';
import GoTop from './components/js files/GoTop';
import backImg from './components/js files/background.jpg'




function App() {
  return (
   <>
   <div style={{
        backgroundImage:`url(${backImg})`,
        // height:'100vh',
        // marginTop:'-70px',
        // fontSize:'50px',
        backgroundSize: '1750px',
        backgroundRepeat: 'repeat',
    }}>
   <BrowserRouter >
    <Navbar placeholder = 'Search News' data={searchData}/>
    <JustScroll key = 'justscroll'/>
      <Routes>
        {/* <Route path='/justscroll' element={<JustScroll key = 'justscroll'/>}></Route> */}
        <Route path='/sports' element={<News key = 'sports' pageSize={6} country='in' category="sports"/>}></Route>
        <Route path='/science' element={<News key = 'science' pageSize={6} country='in' category="science"/>}></Route>
        <Route path='/business' element={<News key = 'business' pageSize={6} country='in' category="business"/>}></Route>
        <Route path='/technology' element={<News key = 'technology' pageSize={6} country='in' category="technology"/>}></Route>
        <Route path='/health' element={<News key = 'health' pageSize={6} country='in' category="health"/>}></Route>
        <Route path='/entertainment' element={<News key = 'entertainment' pageSize={6} country='in' category="entertainment"/>}></Route>
      </Routes>
    <GoTop/>
   </BrowserRouter>
   </div>
   </>
  );
}

export default App;
